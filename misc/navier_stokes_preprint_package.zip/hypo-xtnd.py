"""
Extended Hypothesis Testing for Navier-Stokes Singularities
============================================================

This script performs a fine-grained parameter sweep within the
"sweet spot" of initial conditions identified by hypo-test.py
to get a higher-resolution view of the system's dynamics.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fftn, ifftn
from scipy.optimize import differential_evolution
import warnings
warnings.filterwarnings('ignore')

# For symbolic regression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
import sympy as sp

# (All classes: HRFNavierStokesPOC_3D, SymbolicRegressionAnalyzer, FilterDiscovery
#  are copied verbatim from clay_3d.py here)
class HRFNavierStokesPOC_3D:
    def __init__(self, N=32, nu=0.01):
        self.N, self.nu = N, nu
        self.discovered_filter = None
        kx_1d, ky_1d, kz_1d = (np.fft.fftfreq(N) * N,)*3
        self.kx, self.ky, self.kz = np.meshgrid(kx_1d, ky_1d, kz_1d, indexing='ij')
        self.k2 = self.kx**2 + self.ky**2 + self.kz**2
        self.k2_nozero = self.k2.copy(); self.k2_nozero[0,0,0] = 1e-10
        kmax = N*2/3/2
        self.dealias_mask = (np.abs(self.kx)<kmax) & (np.abs(self.ky)<kmax) & (np.abs(self.kz)<kmax)
        self.coefficient_history, self.time_history, self.energy_history, self.enstrophy_history, self.singularity_indicators = [],[],[],[],[]
    def simulate(self, u0, v0, w0, T=1.0, dt=0.001, verbose=True):
        u_hat, v_hat, w_hat = fftn(u0), fftn(v0), fftn(w0)
        if self.discovered_filter is not None:
            if verbose: print("Applying discovered spectral filter...")
            u_hat *= self.discovered_filter; v_hat *= self.discovered_filter; w_hat *= self.discovered_filter
        t, step = 0, 0
        if verbose: print("Starting 3D simulation...")
        while t < T:
            self.coefficient_history.append({'u_hat':u_hat.copy(),'v_hat':v_hat.copy(),'w_hat':w_hat.copy()}); self.time_history.append(t)
            self._calculate_indicators(u_hat, v_hat, w_hat)
            max_coeff = max(np.max(np.abs(u_hat)), np.max(np.abs(v_hat)), np.max(np.abs(w_hat)))
            if max_coeff > 1e12 or np.isnan(max_coeff):
                if verbose: print(f"Potential blow-up detected at t={t:.4f}, max|coeff|={max_coeff:.2e}")
                break
            u_hat, v_hat, w_hat = self._time_step(u_hat, v_hat, w_hat, dt)
            t += dt; step += 1
            if verbose and step % 20 == 0: print(f"t={t:.3f}, max|u_hat|={np.max(np.abs(u_hat)):.3e}")
        return self._analyze_results()
    def _time_step(self, u_hat, v_hat, w_hat, dt):
        u,v,w = ifftn(u_hat).real, ifftn(v_hat).real, ifftn(w_hat).real
        ux,uy,uz = ifftn(1j*self.kx*u_hat).real, ifftn(1j*self.ky*u_hat).real, ifftn(1j*self.kz*u_hat).real
        vx,vy,vz = ifftn(1j*self.kx*v_hat).real, ifftn(1j*self.ky*v_hat).real, ifftn(1j*self.kz*v_hat).real
        wx,wy,wz = ifftn(1j*self.kx*w_hat).real, ifftn(1j*self.ky*w_hat).real, ifftn(1j*self.kz*w_hat).real
        Nu,Nv,Nw = -(u*ux+v*uy+w*uz), -(u*vx+v*vy+w*vz), -(u*wx+v*wy+w*wz)
        Nu_hat,Nv_hat,Nw_hat = fftn(Nu),fftn(Nv),fftn(Nw)
        Nu_hat[~self.dealias_mask]=0; Nv_hat[~self.dealias_mask]=0; Nw_hat[~self.dealias_mask]=0
        diff_term = 1/(1+self.nu*dt*self.k2)
        u_star,v_star,w_star = (u_hat+dt*Nu_hat)*diff_term, (v_hat+dt*Nv_hat)*diff_term, (w_hat+dt*Nw_hat)*diff_term
        div_u_star = 1j*self.kx*u_star + 1j*self.ky*v_star + 1j*self.kz*w_star
        p_hat = (1j/(dt*self.k2_nozero))*div_u_star
        u_hat_new = u_star - dt*(1j*self.kx*p_hat)
        v_hat_new = v_star - dt*(1j*self.ky*p_hat)
        w_hat_new = w_star - dt*(1j*self.kz*p_hat)
        return u_hat_new, v_hat_new, w_hat_new
    def _calculate_indicators(self,u,v,w):
        energy_density = 0.5*(np.abs(u)**2+np.abs(v)**2+np.abs(w)**2); energy = energy_density/(self.N**6)
        self.energy_history.append(np.sum(energy)); self.enstrophy_history.append(np.sum(self.k2*energy))
        high_k_mask = self.k2 > (self.N/4)**2
        self.singularity_indicators.append(np.sum(energy[high_k_mask])/(np.sum(energy)+1e-12))
    def _analyze_results(self):
        if not self.coefficient_history: return {'time_history':[]}
        final_coeffs = self.coefficient_history[-1]
        return {'coefficient_history':self.coefficient_history, 'time_history':self.time_history, 'energy_history':self.energy_history,
                'enstrophy_history':self.enstrophy_history, 'singularity_indicators':self.singularity_indicators,
                'final_state': {'u_hat':final_coeffs['u_hat'],'v_hat':final_coeffs['v_hat'],'w_hat':final_coeffs['w_hat']}}

class SymbolicRegressionAnalyzer:
    def __init__(self): self.discovered_laws=[]
    def discover_blow_up_law(self, times, max_coeffs):
        X, y = times.reshape(-1,1), np.log(max_coeffs+1e-12)
        best_score, best_model, best_formula = -np.inf,None,None
        for degree in range(1,5):
            model = make_pipeline(PolynomialFeatures(degree), Ridge(alpha=0.01)); model.fit(X,y)
            if model.score(X,y) > best_score:
                best_score, best_model = model.score(X,y), model
                t = sp.Symbol('t'); formula = model.named_steps['ridge'].intercept_
                for i,name in enumerate(model.named_steps['polynomialfeatures'].get_feature_names_out(['t'])[1:]):
                    formula += model.named_steps['ridge'].coef_[i+1] * t**(int(name.split('^')[1]) if '^' in name else 1)
                best_formula = sp.exp(formula)
        blow_up_time = self._estimate_blow_up_time(times, max_coeffs)
        return {'formula':best_formula, 'score':best_score, 'blow_up_time':blow_up_time, 'type':self._classify_singularity(times,max_coeffs)}
    def _estimate_blow_up_time(self,times,values):
        if len(times)<5: return None
        log_values=np.log(values+1e-12); slope=(log_values[-1]-log_values[-5])/(times[-1]-times[-5])
        return times[-1]+(25-log_values[-1])/slope if slope>0 else None
    def _classify_singularity(self,times,values):
        if len(values)<10: return "unknown"
        growth_rates=np.diff(np.log(values+1e-12))/np.diff(times)
        if np.mean(np.diff(growth_rates))>0.01: return "super-exponential"
        return "exponential" if np.std(growth_rates)<0.1*np.mean(growth_rates) else "irregular"

class FilterDiscovery:
    def __init__(self, N=16, nu=0.01):
        self.N, self.nu = N, nu; self.discovered_filters=[]
        kx_1d,ky_1d,kz_1d=(np.fft.fftfreq(N)*N,)*3
        self.kx,self.ky,self.kz=np.meshgrid(kx_1d,ky_1d,kz_1d,indexing='ij')
        self.k_mag=np.sqrt(self.kx**2+self.ky**2+self.kz**2)
    def discover_filter(self,u0,v0,w0,objective_type='peak_enstrophy'):
        print(f"\n-- Starting discovery (Objective: {objective_type}) --")
        def objective(params): return -self._evaluate_filter(self._params_to_filter(params),u0,v0,w0,objective_type)
        bounds=[(self.N/8,self.N/2),(self.N/16,self.N/4),(1.0,1.5)]
        result=differential_evolution(objective,bounds,maxiter=8,popsize=5,disp=True) # More iterations
        optimal_filter=self._params_to_filter(result.x); self.discovered_filters.append(result.x)
        print("-- Filter discovery complete --")
        return optimal_filter, result.x
    def _params_to_filter(self,params):
        center_k,width,amplitude=params
        return 1.0+(amplitude-1.0)*np.exp(-((self.k_mag-center_k)**2)/(2*width**2))
    def _evaluate_filter(self,filter_3d,u0,v0,w0,objective_type):
        temp_solver=HRFNavierStokesPOC_3D(N=self.N,nu=self.nu); temp_solver.discovered_filter=filter_3d
        T_eval=0.1; results=temp_solver.simulate(u0,v0,w0,T=T_eval,dt=0.002,verbose=False)
        if not results['enstrophy_history']: return 0
        if objective_type=='peak_enstrophy': return max(results['enstrophy_history'])
        elif objective_type=='growth_rate':
            enstrophy=np.array(results['enstrophy_history'])
            return (enstrophy[-1]-enstrophy[0])/T_eval if len(enstrophy)>1 else 0
        else: raise ValueError(f"Unknown objective type: {objective_type}")

# (Initial condition functions copied verbatim)
def create_taylor_green_vortex(N):
    x,y,z=(np.linspace(0,2*np.pi,N,endpoint=False),)*3; X,Y,Z=np.meshgrid(x,y,z,indexing='ij')
    u0=np.sin(X)*np.cos(Y)*np.cos(Z); v0=-np.cos(X)*np.sin(Y)*np.cos(Z); w0=np.zeros_like(X)
    noise=0.05; u0+=noise*np.random.randn(N,N,N); v0+=noise*np.random.randn(N,N,N); w0+=noise*np.random.randn(N,N,N)
    return u0,v0,w0
def create_antiparallel_vortices(N, strength=5.0, separation=np.pi):
    print(f"Creating anti-parallel vortices (separation={separation:.2f})...")
    x,y,z=(np.linspace(0,2*np.pi,N,endpoint=False),)*3; X,Y,Z=np.meshgrid(x,y,z,indexing='ij')
    u0,v0,w0 = np.zeros((N,N,N)), np.zeros((N,N,N)), np.zeros((N,N,N))
    radius=np.pi/4; x1,y1 = np.pi-separation/2,np.pi/2; x2,y2 = np.pi+separation/2,np.pi/2
    w0 += strength*np.exp(-(((X-x1)**2+(Y-y1)**2)/radius**2))
    w0 -= strength*np.exp(-(((X-x2)**2+(Y-y2)**2)/radius**2))
    noise=0.1; u0+=noise*np.sin(2*Z); v0+=noise*np.cos(2*Z)
    return u0,v0,w0

def run_single_experiment(initial_condition_params):
    ic_type = initial_condition_params['type']
    print("\n" + "="*80)
    print(f"RUNNING EXPERIMENT: {ic_type} with params {initial_condition_params}")
    print("="*80)
    N,nu,T,dt = 32,0.01,0.5,0.001
    if ic_type == 'antiparallel_vortices':
        u0,v0,w0 = create_antiparallel_vortices(N, separation=initial_condition_params['separation'])
    else: u0,v0,w0 = create_taylor_green_vortex(N)
    
    N_discover=16
    u0s,v0s,w0s=u0[:N_discover,:N_discover,:N_discover],v0[:N_discover,:N_discover,:N_discover],w0[:N_discover,:N_discover,:N_discover]
    discoverer = FilterDiscovery(N=N_discover,nu=nu)
    discovered_filter, filter_params = discoverer.discover_filter(u0s,v0s,w0s)
    
    solver = HRFNavierStokesPOC_3D(N=N, nu=nu)
    solver.discovered_filter = np.kron(discovered_filter, np.ones((2,2,2)))
    results = solver.simulate(u0, v0, w0, T=T, dt=dt)
    
    if len(results['time_history']) < 5: return None
    
    times = np.array(results['time_history'])
    max_coeffs = np.array([max(np.max(np.abs(c['u_hat'])),np.max(np.abs(c['v_hat'])),np.max(np.abs(c['w_hat']))) for c in results['coefficient_history']])
    sr_analyzer = SymbolicRegressionAnalyzer()
    blow_up_law = sr_analyzer.discover_blow_up_law(times, max_coeffs)
    
    # Save plots
    plot_filename = f"hypo_xtnd_{ic_type}_sep_{initial_condition_params.get('separation', 'N/A'):.2f}"
    plot_results(times, max_coeffs, results, blow_up_law, f"{plot_filename}_summary.png")
    if results.get('final_state'):
        plot_vorticity_slices(results['final_state'], solver, f"{plot_filename}_vorticity.png")
        
    return {'filter_params': filter_params, 'blow_up_law': blow_up_law}

def plot_sweep_results(sweep_params, sweep_results, filename):
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    fig.suptitle("Extended Hypothesis Test Sweep Results", fontsize=16)
    
    # Plot 1: Discovered Filter Parameters vs. Separation
    ax1 = axes[0]
    filter_params = np.array([res['filter_params'] for res in sweep_results])
    separations = np.array(sweep_params)
    ax1.plot(separations, filter_params[:, 0], 'o-', label='Center Wavenumber (k)')
    ax1.plot(separations, filter_params[:, 1], 's-', label='Filter Width')
    ax1.set_xlabel("Vortex Separation Distance")
    ax1.set_ylabel("Filter Parameter Value")
    ax1.set_title("Discovered Filter vs. Initial Geometry")
    ax1.legend(); ax1.grid(True)

    # Plot 2: Blow-up Time vs. Separation
    ax2 = axes[1]
    blow_up_times = [res['blow_up_law']['blow_up_time'] for res in sweep_results]
    ax2.plot(separations, blow_up_times, 'o-')
    ax2.set_xlabel("Vortex Separation Distance")
    ax2.set_ylabel("Estimated Blow-up Time")
    ax2.set_title("Singularity Time vs. Initial Geometry")
    ax2.grid(True)

    plt.tight_layout(rect=[0,0,1,0.95])
    plt.savefig(filename)
    plt.show()

# (Plotting functions are modified to not show plots interactively during the sweep)
def plot_results(times, max_coeffs, results, blow_up_law, filename):
    fig,axes=plt.subplots(2,2,figsize=(12,10));fig.suptitle("Singularity Analysis",fontsize=16)
    ax=axes[0,0];ax.semilogy(times,max_coeffs,'b-',label='Sim');t=sp.Symbol('t')
    try:
        f=sp.lambdify(t,blow_up_law['formula'],'numpy');t_fine=np.linspace(times[0],times[-1],200)
        with warnings.catch_warnings(): warnings.simplefilter("ignore");y_pred=f(t_fine)
        ax.semilogy(t_fine,y_pred,'r--',label='Law')
    except Exception: pass
    ax.set_title('Coefficient Blow-up');ax.legend();ax.grid(True,alpha=0.3)
    axes[0,1].plot(times,results['energy_history'],'g-');axes[0,1].set_title('Energy')
    axes[1,0].semilogy(times,results['enstrophy_history'],'m-');axes[1,0].set_title('Enstrophy')
    axes[1,1].plot(times,results['singularity_indicators'],'r-');axes[1,1].set_title('Singularity Indicator')
    plt.tight_layout(rect=[0,0,1,0.95]);plt.savefig(filename,dpi=120);plt.close(fig)
def plot_vorticity_slices(final_state, solver, filename):
    print(f"Plotting vorticity slices to {filename}...")
    u_hat,v_hat,w_hat=final_state['u_hat'],final_state['v_hat'],final_state['w_hat']
    omega_x_hat = 1j*solver.ky*w_hat-1j*solver.kz*v_hat
    omega_y_hat = 1j*solver.kz*u_hat-1j*solver.kx*w_hat
    omega_z_hat = 1j*solver.kx*v_hat-1j*solver.ky*u_hat
    omega_x,omega_y,omega_z=ifftn(omega_x_hat).real,ifftn(omega_y_hat).real,ifftn(omega_z_hat).real
    vort_mag = np.sqrt(omega_x**2+omega_y**2+omega_z**2)
    fig,axes=plt.subplots(1,3,figsize=(18,5));fig.suptitle('Vorticity Slices',fontsize=16)
    s_idx=solver.N//2
    im1=axes[0].imshow(vort_mag[:,:,s_idx],cmap='inferno');axes[0].set_title(f'XY @ z={s_idx}');fig.colorbar(im1,ax=axes[0])
    im2=axes[1].imshow(vort_mag[:,s_idx,:],cmap='inferno');axes[1].set_title(f'XZ @ y={s_idx}');fig.colorbar(im2,ax=axes[1])
    im3=axes[2].imshow(vort_mag[s_idx,:,:],cmap='inferno');axes[2].set_title(f'YZ @ x={s_idx}');fig.colorbar(im3,ax=axes[2])
    plt.tight_layout(rect=[0,0,1,0.95]);plt.savefig(filename,dpi=120);plt.close(fig)

if __name__ == "__main__":
    # Define the fine-grained parameter sweep
    separations_to_test = np.linspace(0.9, 1.4, 8)
    sweep_results = []
    
    for sep in separations_to_test:
        params = {'type': 'antiparallel_vortices', 'separation': sep}
        result = run_single_experiment(params)
        if result:
            sweep_results.append(result)
    
    # Analyze the collected results from the sweep
    if len(sweep_results) > 1:
        plot_sweep_results(separations_to_test, sweep_results, "hypo_xtnd_sweep_summary.png")

    print("\n\nExtended hypothesis testing complete.")
    print("Check the generated image files for results of each run and the new sweep summary.")
